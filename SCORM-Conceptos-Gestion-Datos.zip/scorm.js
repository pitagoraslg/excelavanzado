/* Seguimiento SCORM 1.2 para Moodle: cada diapositiva es un tema del índice de Moodle */
(function(){
  "use strict";
  // mismos títulos que imsmanifest.xml, en orden de diapositiva
  var TEMAS = ['Portada', 'Las cinco cualidades', 'Tabla de Excel', 'Duplicados', 'El filtro',
    'Buscar y reemplazar', 'Ctrl + Enter e Ir a Especial', 'Valor vs. formato', 'Formatos para montos',
    'Ordenar', 'Escritorio vs. web', 'Cierre', 'Bibliografía'];

  function findAPI(w){
    for(var n = 0; w && n < 10; n++){
      try { if(w.API) return w; } catch(e){}
      if(w.parent === w) break;
      w = w.parent;
    }
    return null;
  }
  var lms = findAPI(window) || (window.opener ? findAPI(window.opener) : null);
  var api = lms ? lms.API : null;
  var t0 = Date.now(), gone = false, pending = false;
  var m = /[?&]s=(\d+)/.exec(location.search);
  var start = m ? parseInt(m[1], 10) - 1 : null;

  function set(k, v){ try { if(api) api.LMSSetValue(k, String(v)); } catch(e){} }
  function commit(){ try { if(api) api.LMSCommit(''); } catch(e){} }

  if(api){
    try { api.LMSInitialize(''); } catch(e){}
    // Moodle abre el primer tema no completado: los temas quedan «en progreso»
    // para que siempre se entre por la Portada; al llegar al Cierre se completa.
    set('cmi.core.lesson_status', start !== null && start >= TEMAS.length - 2 ? 'completed' : 'incomplete');
    commit();
  }

  function pad(n){ return (n < 10 ? '0' : '') + n; }
  function sessionTime(){
    var s = Math.round((Date.now() - t0) / 1000);
    return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60);
  }
  var finished = false;
  function finish(){
    gone = true;
    if(!api || finished) return;
    finished = true;
    set('cmi.core.session_time', sessionTime());
    commit();
    try { api.LMSFinish(''); } catch(e){}
  }
  window.addEventListener('pagehide', finish);
  window.addEventListener('beforeunload', finish);

  // clic en el tema dentro del índice de Moodle
  function clickToc(title){
    try {
      var doc = lms.document, box = doc.getElementById('scorm_toc') || doc.getElementById('scorm_tree') || doc.querySelector('[id^="scorm_toc"], [id^="scorm_tree"]');
      if(!box) return false;
      var links = box.querySelectorAll('a');
      for(var k = 0; k < links.length; k++){
        if(links[k].textContent.replace(/\s+/g, ' ').trim() === title){ links[k].click(); return true; }
      }
    } catch(e){}
    return false;
  }

  // 1) función de Moodle, 2) índice de Moodle, 3) cambio local de diapositiva
  function launch(fn, target, local){
    if(pending) return true; // evita doble clic
    pending = true;
    try { if(typeof lms[fn] === 'function') lms[fn](); } catch(e){}
    setTimeout(function(){
      if(gone) return;
      clickToc(TEMAS[target]);
      setTimeout(function(){ pending = false; if(!gone) local(); }, 1200);
    }, 1200);
    return true;
  }

  // la primera vez que se abre el reproductor, empezar por la Portada
  try {
    if(lms && !lms.__icadepEntrada){
      lms.__icadepEntrada = true;
      if(start !== null && start > 0) setTimeout(function(){ clickToc(TEMAS[0]); }, 300);
    }
  } catch(e){}

  window.SCORM = {
    lms: !!api,
    start: start,
    next: function(cur, total, local){ return api && cur < total - 1 ? launch('mod_scorm_launch_next_sco', cur + 1, local) : false; },
    prev: function(cur, local){ return api && cur > 0 ? launch('mod_scorm_launch_prev_sco', cur - 1, local) : false; }
  };
})();
